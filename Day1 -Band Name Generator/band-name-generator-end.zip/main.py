#1. Create a greeting for your program.
print("Hello! Welcome to my First Project of 100 days with Python")

print("This code will suggest you nice Band Name!")
#2. Ask the user for the city that they grew up in.
city =  input("Please enter the city you grew up in !")

#3. Ask the user for the name of a pet.
pet = input("Please enter your favourite pet name here !")

#4. Combine the name of their city and pet and show them their band name.
BandName = city +" "+ pet

#5. Make sure the input cursor shows on a new line, see the example at:

print("Your band name suggestion is "+ BandName)

#  https://band-name-generator-end.appbrewery.repl.run/