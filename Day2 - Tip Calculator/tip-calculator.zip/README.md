
Day 2 of Python code 100Daysof Python.

Effective use of input , print functions and math operations.

Simply click run button (or run the code in ide with python main.py) and follow the instructions to get the desired results.